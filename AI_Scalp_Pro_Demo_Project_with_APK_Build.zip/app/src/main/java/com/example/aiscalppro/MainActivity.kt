package com.example.aiscalppro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val bg = Color(0xFF0B1220)
private val panel = Color(0xFF172235)
private val green = Color(0xFF38D996)
private val red = Color(0xFFFF6B75)
private val muted = Color(0xFF9BAAC0)

data class SampleCoin(val pair: String, val price: String, val volume: String, val demoTag: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DemoApp() }
    }
}

@Composable
fun DemoApp() {
    var tab by remember { mutableStateOf("Scanner") }
    val coins = listOf(
        SampleCoin("BTC/USDT", "—", "—", "WAIT"),
        SampleCoin("ETH/USDT", "—", "—", "WAIT"),
        SampleCoin("SOL/USDT", "—", "—", "WAIT"),
        SampleCoin("BNB/USDT", "—", "—", "WAIT"),
        SampleCoin("XRP/USDT", "—", "—", "WAIT")
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = panel, primary = green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(bg).padding(16.dp)) {
            Text("AI SCALP PRO", color = green, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text("EDUCATIONAL PAPER-TRADING DEMO", color = muted, fontSize = 10.sp)
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("SIMULATED BALANCE", color = muted, fontSize = 11.sp)
                    Text("100.00 USDT", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Practice account • No real funds", color = green, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Scanner", "Practice", "Stats").forEach { label ->
                    Button(onClick = { tab = label }, colors = ButtonDefaults.buttonColors(
                        containerColor = if (tab == label) green else panel,
                        contentColor = if (tab == label) bg else Color.White
                    )) { Text(label) }
                }
            }
            Spacer(Modifier.height(12.dp))
            when (tab) {
                "Scanner" -> {
                    Text("WATCHLIST", color = muted, fontWeight = FontWeight.Bold)
                    Text("Sample rows only — live data not connected yet.", color = muted, fontSize = 12.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(coins) { coin ->
                            Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text(coin.pair, fontWeight = FontWeight.Bold)
                                        Text("Price ${coin.price} • 24h volume ${coin.volume}", color = muted, fontSize = 11.sp)
                                    }
                                    Text(coin.demoTag, color = muted, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                "Practice" -> {
                    Text("PAPER PRACTICE", color = muted, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("This area is reserved for simulated trade journaling and learning. It will not send orders.", color = Color.White)
                }
                else -> {
                    Text("PERFORMANCE", color = muted, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("No results yet. Practice sessions can be logged here; win rate should be calculated from recorded outcomes, not promised.", color = Color.White)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Risk note: this demo is for learning only. No live BUY/SELL recommendations or order execution.", color = muted, fontSize = 10.sp)
        }
    }
}
