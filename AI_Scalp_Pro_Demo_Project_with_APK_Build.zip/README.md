# AI Scalp Pro — Android Demo

Educational **paper-trading** prototype. It does not connect to a trading account, place orders, or give actionable trading recommendations.

## Open
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Run on an Android emulator/device.

This starter UI uses illustrative sample market rows and a simulated USDT balance. It is an interface prototype, not a compiled APK.
